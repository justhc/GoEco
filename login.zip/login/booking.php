<!DOCTYPE html>
<html>
<head>
	<title>Booking Page</title>
	<link rel="stylesheet" type="text/css" href="style3.css">
	<link rel="stylesheet" type="text/css"
	href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
	<div class="container"> 
		<div class="login-box">
		<div class="row">
			<div class="col-md-6" login-left>
				<h2> Please do enter your details </h2>
				<form action="confirmation.php" method="post">
					<div class="form-group">
						<label> Username </label>
						<input type="text" name="user" class="form-control" required>
					</div>
					<div class="form-group">
						<label> First Name </label>
						<input type="text" name="firstname" class="form-control" required>
					</div>
					<div class="form-group">
						<label> Last Name </label>
						<input type="text" name="lastname" class="form-control" required>
					</div>
					<div class="form-group">
						<label> Email id </label>
						<input type="emailid" name="emailid" class="form-control" required>
					</div>
					<div class="form-group">
						<label> Phone number </label>
						<input type="number" name="phonenumber" class="form-control" required>
					</div>
					<div class="form-group">
						<label> Gender </label>
						<input type="text" name="gender" class="form-control" required>
					</div>
					<div class="form-group">
						<label> Home Address </label>
						<input type="Address" name="homeaddress" class="form-control" required>
					</div>
					<div class="form-group">
						<label> IT Company </label>
						<input type="Address" name="itcompany" class="form-control" required>
					</div>
					<div class="form-group">
						<label> Company Branch </label>
						<input type="text" name="branch" class="form-control" required>
					</div>
					<div class="form-group">
						<label> Work Address </label>
						<input type="text" name="workaddress" class="form-control" required>
					</div>
					<button type="submit" class="btn btn-primary"> Submit </button>
				</form>
				
			</div>
		</div>
	</div>
</div>
</body>
</html>
