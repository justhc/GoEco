

<html>
<head>
	<link rel="stylesheet" href="bdone.css">
	<href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<header>
		<div class="wrapper">
			<div class="logo">
				<img src="images/logo.png" alt="">
			</div>
			<ul class="nav-area">
				<li><a href="about.php">ABOUT</a></li>
				<li><a href="login.php">SIGN UP/LOG IN</a></li>
				<li><a href="mybooking.php">MY BOOKINGS</a></li>
				<li><a href="contact.php">CONTACT</a></li>
			</ul>
		</div>
		<div class="welcome-text">
			<h1>You're already a registered user, click on log in to contine!</h1>
			
	</header>
</div>
	</body>
	</html>




