create table logininfo(user varchar(100), password varchar(100));
create table customer(firstname varchar(100), lastname varchar(100), emailid varchar(150), phonenumber varchar(15), gender varchar(10));
create table company(itcompany varchar(100), branch varchar(100));
create table address(homeaddress varchar(255), workaddress varchar(255));
create table car(cartype varchar(100));
create table bookingstatus(phonenumber varchar(15) references customer(phonenumber), timed time, dated date, pickup varchar(200), des varchar(200));
create table paymenttype(payment varchar(100));

insert into logininfo values('TejasMenon','tejas@1234');
insert into logininfo values('NeysaKrishnan','neysa@1234');
insert into logininfo values('AdityaChoudary','aditya@1234');

insert into customer values('Tejas','Menon','tejasmenon@gmail.com','9901824710','Male');
insert into customer values('Neysa','Krishnan','neysakrishnan@gmail.com','7022589633','Female');
insert into customer values('Aditya','Choudary','adityachoudary@gmail.com','7337723609','Male');

insert into company values('TCS','Whitefield');
insert into company values('MindTree','Hebbal');
insert into company values('Accenture','Tilaknagar');

insert into address values('156/2 9th Cross 6th B Mainroad Rajajinagar Bengaluru 560054','Gopalan Global Axis, Unit-I & Unit-II, No. 152, EPIP Zone, Whitefield, Bengaluru, Karnataka 560066');
insert into address values('Mysore Rd, RVCE, Bengaluru, Karnataka 560059','Global village Tech Park, Hebbal, Bengaluru, Karnataka 560059');
insert into address values('126/5 7th cross 8th B Mainroad Banashankari Bengaluru 560034','132/1 32nd Cross, Near Sagar Hospitals, Bengaluru, Karnataka 560059');

insert into car values('GoEco SharePrime');
insert into car values('GoEco ShareSedan');
insert into car values('GoEco Share');

insert into bookingstatus values('9901824710','10:00:00', '2021-01-11','156/2 9th Cross 6th B Mainroad Rajajinagar Bengaluru 560054','Gopalan Global Axis, Unit-I & Unit-II, No. 152, EPIP Zone, Whitefield, Bengaluru, Karnataka 560066');
insert into bookingstatus values('7022589633','11:00:00', '2021-01-10','Mysore Rd, RVCE, Bengaluru, Karnataka 560059','Global village Tech Park, Hebbal, Bengaluru, Karnataka 560059');
insert into bookingstatus values('7337723609','10:00:00', '2021-01-12','126/5 7th cross 8th B Mainroad Banashankari Bengaluru 560034','132/1 32nd Cross, Near Sagar Hospitals, Bengaluru, Karnataka 560059');

insert into paymenttype values('Cash');
insert into paymenttype values('Debit Card');
insert into paymenttype values('GooglePay');
