<html>
<head>
	<title>About </title>
	<link rel="stylesheet" href="about.css">
	
<body>

<header>
		<div class="wrapper">
			<div class="logo">
	        <img src="images/logo.png" alt="">
			</div>
			<div class="welcome-text">
			<h1>About GoEco</h1>
			<h2><br><i> Founded by Sindhu Bhaskar and Shalini Gajendra in the year 2002.</i></h2>
			<h3><br><b><i><u> WHY US? </i></b></u><br>This service was initiated with the sole purpose of us, all together making our city a bit greener and less polluted. The Silicon Valley boosts many IT Companies and we provide you with cabs solely for car pooling.<br><br> 
			<p><br>GoEco has been growing much more from the time it has been founded and we thank each and every one who are a part of this family striving towards a better, greener world and future. 
			Register with us and be a part of this initiative now!! </p> 
		</i>
	</b>
</h3>
</div>
</div>
</header>
</body>
 </head>
 </html>


	