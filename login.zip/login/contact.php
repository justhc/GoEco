<html>
<head>
	<title>About </title>
	<link rel="stylesheet" href="contact.css">
	<href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<header>
		<div class="wrapper">
			<div class="logo">
	        <img src="images/logo.png" alt="">
			<div class="welcome-text">
			<h1><i> <u>CONTACT US</i></u> <br>
			<br> </h1>
			<h2> @GoEco Technologies </h2><br>
			<h3>#21, 15 'A' cross, Bendrenagar, Uttarahalli Main Road, Subramanyapura Main Road, Opposite Maruti Suzuki Showroom, Bengaluru - 560070
				<br><br> GSTIN : 29ABQPL6686C2Z1 <br> <br>
				Telephone Number : 080 26769453 <br> <br>
				WhatsApp Number : 7022589633
			</h3>

</div>
		</div>
			</div>	
</header>
		</body>
</html>