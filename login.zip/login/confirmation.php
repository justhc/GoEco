<?php

session_start();
$con=mysqli_connect('localhost','root','mbsp2427.');
mysqli_select_db($con,'userregistration');
$name=$_POST['user'];
$fn=$_POST['firstname'];
$ln=$_POST['lastname'];
$eid=$_POST['emailid'];
$phno=$_POST['phonenumber'];
$gen=$_POST['gender'];
$ha=$_POST['homeaddress'];
$it=$_POST['itcompany'];
$itb=$_POST['branch'];
$wa=$_POST['workaddress'];

$s="select * from logininfo where user='$name'";
$result=mysqli_query($con,$s);


if(mysqli_num_rows($result)){
	$reg1="insert into customer(firstname,lastname,emailid,phonenumber,gender)  values ('$fn','$ln','$eid','$phno','$gen')";
	$reg2="insert into company(itcompany,branch) values ('$it','$itb')";
	$reg3="insert into address(homeaddress,workaddress) values ('$ha','$wa')";
	mysqli_query($con,$reg1);
	mysqli_query($con,$reg2);
	mysqli_query($con,$reg3);
	header('location:travel.php');

}
else{
	header('location:wrong.php');

}


?>