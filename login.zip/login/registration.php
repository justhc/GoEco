<?php

session_start();
header('location:login.php');
$con=mysqli_connect('localhost','root','mbsp2427.');
mysqli_select_db($con,'userregistration');
$name=$_POST['user'];
$pass=$_POST['password'];

$s="select * from logininfo where user='$name'";
$result=mysqli_query($con,$s);


if(mysqli_num_rows($result)){
     
	header('location:alreadyregistered.php');
}
else
{
	$reg="insert into logininfo (user,password) values ('$name','$pass')";
	mysqli_query($con,$reg);
	header('location:booking.php');

}


?>