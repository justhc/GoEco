<!DOCTYPE html>
<html>
<head>
	<title>Login and Registration page</title>
	<link rel="stylesheet" type="text/css" href="style4.css">
	<link rel="stylesheet" type="text/css"
	href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
	<div class="container"> 
		<div class="login-box">
		<div class="row">
			<div class="col-md-6" login-left>
				<h2> Book your cab here! </h2>                   
				<form action="save.php" method="post">
					<div class="form-group">
						<label> Enter your phone number: </label>
						<input type="text" name="phonenumber" class="form-control" required>
					</div>
					<div class="form-group">
						<label> Enter your pick up address </label>
						<input type="text" name="pickup" class="form-control" required>
					</div>
					<div class="form-group">
						<label> Enter your destination </label>
						<input type="text" name="des" class="form-control" required>
					</div>
				    <div class="form-group">
						<label> Enter your choice of car : (GoEco SharePremium/ GoEco ShareSedan / GoEco Share)</label>
						<input type="text" name="cartype" class="form-control" required>
					</div>
					<div class="form-group">
						<label> Enter the time : (In 'HH:MM' format) </label>
						<input type="text" name="timed" class="form-control" required>
					</div>
					<div class="form-group">
						<label> Enter the date : (In 'YYYY-MM-DD') </label>
						<input type="text" name="dated" class="form-control" required>
					</div>
					<div class="form-group">
						<label> Enter the method of payment :  (Cash/ Debit card/ Online transaction)</label>
						<input type="text" name="payment" class="form-control" required>
					</div>
					
                    
					<button type="submit" class="btn btn-primary"> Book </button>
				</form>
			</div>
		</div>
	</div>
</div>
</body>
</body>
</html>

