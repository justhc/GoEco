<?php 

session_start();
$con=mysqli_connect('localhost','root','mbsp2427.');
mysqli_select_db($con,'userregistration');
$pn=$_POST['phonenumber'];
$pa=$_POST['pickup'];
$da=$_POST['des'];
$ct=$_POST['cartype'];
$ti=$_POST['timed'];
$ds=$_POST['dated'];
$pm=$_POST['payment'];


$s="select * from customer where phonenumber='$pn'";
$result=mysqli_query($con,$s);


if(mysqli_num_rows($result)){
	$reg1="insert into bookingstatus(phonenumber,timed, dated, pickup,des) values ('$pn','$ti','$ds','$pa','$da')";
	$reg2="insert into car(cartype) value ('$ct')";
	$reg3="insert into paymenttype(payment) value ('$pm') ";
	mysqli_query($con,$reg1);
	mysqli_query($con,$reg2);
	mysqli_query($con,$reg3);
    header('location:bdone.php');
}
else{
    header('location:wrong.php');
}


?>