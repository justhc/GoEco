<html>
<head>
	<title>Booking Details</title>
	<link rel="stylesheet" href="validation2.css">
	<href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<header>
		<div class="wrapper">
			<div class="logo">
	        <img src="images/image4.png" alt="">
 
<?php

session_start();


$con=mysqli_connect('localhost','root','mbsp2427.');
mysqli_select_db($con,'userregistration');
$name=$_POST['user'];
$phnob=$_POST['phonenumber'];

$s="select * from bookingstatus where phonenumber='$phnob'";
$result=mysqli_query($con,$s);


if(mysqli_num_rows($result)){
	$sql1    = "SELECT firstname, lastname, emailid, phonenumber, gender FROM customer where phonenumber='$phnob'";
            $r1 = mysqli_query($con,$sql1);
                while($row = $r1->fetch_assoc()) {
        echo "<table border='1' width='1350'>
        <tr><th>Name</th>
        <th>Email id</th>
        <th>Phonenumber</th>
        <th>Gender</th>
        </tr>
        <tr><td>". $row["firstname"]. " " . $row["lastname"] . "<br><br></td><td>". $row["emailid"]. "<br><br></td><td>". $row["phonenumber"]. "<br><br></td><td>". $row["gender"] . "<br><br></td></tr>";
        echo '<table><br><br>';
        $sql2    = "SELECT timed, dated, pickup, des FROM bookingstatus where phonenumber='$phnob'";
            $r2 = mysqli_query($con,$sql2);
                while($row = $r2->fetch_assoc()) {
                	echo "<table border= '1' width='1300' >
                	<tr><th>Time of pickup</th>
                	<th>Date of pickup</th>
                	<th>Pickup</th>
                	<th>Destination</th>
                	</tr>
                	<tr><td>". $row["timed"]. "<br><br></td><td>Date of pickup: ". $row["dated"]. "<br><br></td><td>Pickup address: ". $row["pickup"]. "<br><br></td><td>Destination address: ". $row["des"]."<br><br></td></tr>";
                	echo '</table>';

}
    }
}
else{
	header('location:wrong.php');

}
?>

</div>
</div>
</header>
		</body>
</html>

